# AI-Powered PDF Editor

This project is a full-stack web application that allows users to edit, merge, and split PDFs, perform OCR, and summarize text using AI. The frontend is built with React.js, and the backend is built with Express.js (Node.js). The application uses pdf-lib for PDF editing, Tesseract.js for OCR, and the OpenAI API for text summarization.

## Folder Structure
