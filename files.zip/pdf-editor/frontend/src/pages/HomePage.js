import React from 'react';
import FileUpload from '../components/FileUpload';
import PdfEditor from '../components/PdfEditor';
import PdfMerger from '../components/PdfMerger';
import PdfSplitter from '../components/PdfSplitter';
import TextSummarizer from '../components/TextSummarizer';

const HomePage = () => {
  return (
    <div>
      <h1>AI-Powered PDF Editing</h1>
      <FileUpload />
      <PdfEditor />
      <PdfMerger />
      <PdfSplitter />
      <TextSummarizer />
    </div>
  );
};

export default HomePage;