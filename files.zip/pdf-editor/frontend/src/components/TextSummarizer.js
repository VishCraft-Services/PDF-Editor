import React, { useState } from 'react';
import axios from 'axios';

const TextSummarizer = () => {
  const [text, setText] = useState('');
  const [summary, setSummary] = useState('');

  const handleSummarize = async () => {
    try {
      const response = await axios.post('/api/summarize', { text });
      setSummary(response.data.summary);
    } catch (error) {
      console.error('Error summarizing text:', error);
      alert('Text summarization failed');
    }
  };

  return (
    <div>
      <h2>AI Text Summarization</h2>
      <textarea value={text} onChange={(e) => setText(e.target.value)} />
      <button onClick={handleSummarize}>Summarize</button>
      {summary && <p>{summary}</p>}
    </div>
  );
};

export default TextSummarizer;