import React from 'react';

const PdfMerger = () => {
  // Implement PDF merging features here
  return (
    <div>
      <h2>Merge PDFs</h2>
      <button>Merge</button>
    </div>
  );
};

export default PdfMerger;