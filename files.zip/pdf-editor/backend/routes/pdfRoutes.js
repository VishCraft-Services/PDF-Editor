const express = require('express');
const { uploadPdf, modifyPdf, mergePdfs, splitPdf, ocrPdf, summarizeText } = require('../controllers/pdfController');

const router = express.Router();

router.post('/upload', uploadPdf);
router.post('/modify', modifyPdf);
router.post('/merge', mergePdfs);
router.post('/split', splitPdf);
router.post('/ocr', ocrPdf);
router.post('/summarize', summarizeText);

module.exports = router;